﻿using System;
using Microsoft.Maui.Controls;

namespace CalculatorApp
{
    public partial class MainPage : ContentPage
    {
        private string _operator;           // المعامل الرياضي الذي سيتم تطبيقه
        private double _firstNumber;         // الرقم الأول في العملية الحسابية
        private bool _isOperatorClicked;     // للتحقق من حالة النقر على المعامل

        public MainPage()
        {
            InitializeComponent();
        }

        private void OnNumberClicked(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            string number = button.Text;

            // تعيين الرقم المدخل إذا كانت البداية بـ 0 أو تم النقر على معاملة
            if (Result.Text == "0" || _isOperatorClicked)
            {
                Result.Text = number;
                _isOperatorClicked = false;
            }
            else
            {
                Result.Text += number;
            }
        }

        private void OnOperatorClicked(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            _operator = button.Text;
            _firstNumber = Convert.ToDouble(Result.Text);
            _isOperatorClicked = true;
        }

        private void OnClearClicked(object sender, EventArgs e)
        {
            _firstNumber = 0;
            _operator = string.Empty;
            Result.Text = "0";
            _isOperatorClicked = false;
        }

        private void OnCalculateClicked(object sender, EventArgs e)
        {
            // التحقق من وجود معاملة قبل المتابعة
            if (string.IsNullOrEmpty(_operator)) return;

            double secondNumber = Convert.ToDouble(Result.Text);
            double result = 0;

            switch (_operator)
            {
                case "+":
                    result = _firstNumber + secondNumber;
                    break;
                case "-":
                    result = _firstNumber - secondNumber;
                    break;
                case "*":
                    result = _firstNumber * secondNumber;
                    break;
                case "/":
                    // تحقق من عدم القسمة على صفر
                    if (secondNumber == 0)
                    {
                        Result.Text = "Cannot divide by zero";
                        _isOperatorClicked = true;
                        return;
                    }
                    result = _firstNumber / secondNumber;
                    break;
            }

            Result.Text = result.ToString();
            _isOperatorClicked = true;
        }
    }
}
